package com.example.THJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThJavaApplication.class, args);
	}

}
