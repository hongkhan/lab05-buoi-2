package com.example.THJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
